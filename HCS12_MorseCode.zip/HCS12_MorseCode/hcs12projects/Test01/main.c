#include <hcs12.h>
#include <dbug12.h>
#include "util.h"
#include "lcd.h"
#define busy_loop for(int i = 0; i < 10000; i++) {for(int j = 0; j < 10000; j++){}}
#define small_busy for(int i = 0; i < 5000; i++){for(int j = 0; j < 5000; j++){}}




//Holds the values associated with the dot and dash
unsigned int segment_decoder[] = { 0x04,0x40 };


volatile INT8U keypad_on = 0;
volatile unsigned int keypad_debounce = 0;
const unsigned int KEYPAD_LIMIT = 400;
const unsigned char NULL_KEYPAD = '!';


void initializeKeypad()
{
	DDRA |= 0xF0;
	DDRA &= ~0x0F;
	PUCR |= PUCR_PUPAE_MASK;
}


const unsigned char keypad_decoder[4][4] = { {'1', '2', '3', 'A'},
											{'4', '5', '6', 'B'},
											{'7', '8', '9', 'C'},
											{'*', '0', '#', 'D'} };


INT8U readKeypad()
{
	if (keypad_on == 0)
	{
		return NULL_KEYPAD;
	}
	for (INT8U y = 0; y < 4; y++)
	{
		PORTA = 0xF0 & ~(0x10 << y);
		for (INT8U x = 0; x < 4; x++)
		{
			INT8U input = (PORTA & 0x0F);
			if ((input & (1 << x)) == 0)
			{
				keypad_on = 0;
				return keypad_decoder[y][x];
			}
		}
	}
	return NULL_KEYPAD;
}


void display7segment(char n)
{
	if (n == NULL_KEYPAD) return;




	DDRP = 0xff;
	PTP = ~(0x8);




	//turns off LED
	if (n == 'P') {
		PTP = ~(0x1);
		PORTB = 0;
		small_busy;
	}
	if (n == '.') {
		PORTB = segment_decoder[0];
	}
	if (n == '-') {
		PORTB = segment_decoder[1];
	}
}


void displayLCD(char* str)
{
	DispClrScr();
	DispCursorSet(1, 14);
	DispStr(0, 0, str);
}


volatile unsigned int int_counter;
volatile unsigned int int_counter_limit;
volatile INT8U display;


void jobs()
{
	if (keypad_debounce >= KEYPAD_LIMIT)
	{
		keypad_on = 1;
		keypad_debounce = 0;
	}
	else
	{
		keypad_debounce++;
	}
}


void INTERRUPT isr(void)
{
	// clear CRG flag for other interrupts
	CRGFLG = 0x80;
	// counter for jobs
	if (int_counter >= int_counter_limit)
	{
		jobs();
		int_counter = 0;
	}
	else
	{
		int_counter++;
	}
}


void initialize_rti(unsigned char timer, unsigned int counter)
{
	// register interrupt function
	UserRTI = (unsigned int)&isr;
	// sets counter
	int_counter_limit = counter;
	int_counter = 0;
	// sets timer
	RTICTL = timer;
	// enables interrupts
	CRGINT |= 0x80;
	// clear CRG flag
	CRGFLG = 0x80;
}


//Holds morse code for letters
const char* morseCode[] = {
	".-",   // A
	"-...", // B
	"-.-.", // C
	"-..",  // D
	".",    // E
	"..-.", // F
	"--.",  // G
	"....", // H
	"..",   // I
	".---", // J
	"-.-",  // K
	".-..", // L
	"--",   // M
	"-.",   // N
	"---",  // O
	".--.", // P
	"--.-", // Q
	".-.",  // R
	"...",  // S
	"-",    // T
	"..-",  // U
	"...-", // V
	".--",  // W
	"-..-", // X
	"-.--", // Y
	"--.."  // Z
};


//Parses main string, then string of morse code associated with each character
void flashMorseCode(const char* morseString) {
	//string being outputted to LCD
	char* currString = "";


	for (int i = 0; morseString[i] != '\0'; i++) {




		for (int j = 0; morseCode[morseString[i] - 65][j] != '\0'; j++) {
			//turn off led
			display7segment('P');


			if (morseCode[morseString[i] - 65][j] == '-') {
				display7segment('-');
				small_busy;
			}
			if (morseCode[morseString[i] - 65][j] == '.') {
				display7segment('.');
				small_busy;
			}


			display7segment('P');
		}


		//output each letter one at time on the LCD as the morse code happens for each
		currString[i] = morseString[i];
		currString[i + 1] = '\0';
		displayLCD(currString);


		busy_loop;        // Wait between Morse code elements
	}
}




int main(void)
{
	//RTI initialization
	CLKSEL = 0x7F;
	initialize_rti(0x31, 1);
	CLKSEL |= 0x80;
	__asm("cli");


	//Keypad initialization 
	initializeKeypad();


	//7-segment initialization
	DDRB = 0xff;


	//LCD initialization
	DispInit(2, 16);
	DispClrScr();


	//STRING TO TURN INTO MORSE CODE
	char* string = "MORSE CODE TEST";


	while (1)
	{
		if (keypad_on == 1)
		{
			unsigned char input = readKeypad();




			if (input != NULL_KEYPAD)
			{
				if (input == 'A')
				{
					flashMorseCode(string);
				}
			}
		}
	}
}
